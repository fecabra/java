package passos;

public class Estagiario extends Empresa implements getSalario{
	
	private double vale_coxinha;
	
    public Estagiario(int ID, String nome, double salario){
           super(ID, nome, salario );
     }
    
    @Override
    public double getSalario() {
    	return(this.salario+vale_coxinha);
     }
    
    public void setValeCoxinha( double vale_coxinha ){
           this.vale_coxinha = vale_coxinha;
     } 
};
