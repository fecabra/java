package passos;

import java.util.ArrayList;

public class Principal {
	
	public static void main(String[] args) { 
	   
	
		Estagiario estag1 = new Estagiario(0, "Joao", 1500.00); 
		
		Empresa.adiciona(estag1);
		
        Secretaria secre1 = new Secretaria(1, "Rose", 8000.00); 
		
		Empresa.adiciona(secre1);
	
		
		Gerente geren1 = new Gerente(3, "Marco", 12000.00); 
		
		Empresa.adiciona(geren1);
		
		Presidente pres1 = new Presidente(4, "Jose", 18000.00); 
		
		Empresa.adiciona(pres1);
		
	    System.out.println(Empresa.funcionarios);

	    
	    System.out.println(Empresa.Calcsalario(0));
		

		
	}
};
