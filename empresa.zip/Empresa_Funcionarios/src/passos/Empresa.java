package passos;

import java.util.ArrayList; 

public class Empresa {
	

	int ID;
    private String nome;
    public double salario;
    public Empresa(int ID, String nome, double salario) {
          this.setID(ID);
          this.setNome(nome);
          this.salario = salario;
    }
    
    
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Override
	public String toString() {
		return ("\n" + ID + " : " + nome + " : " + salario + "\n");
	}

	
	static ArrayList<Empresa> funcionarios = new ArrayList<Empresa>();
	
	public static ArrayList<Empresa> adiciona(Empresa funcionario) { 
		funcionarios.add(funcionario);
		return funcionarios;
	}
	


	public static ArrayList<Empresa>  CalcSalario(Empresa ID){ 
		 if (ID instanceof Presidente){
			return Presidente.getSalario();
		 }else if (ID instanceof Gerente){
			Gerente.getSalario();
		 }else if (ID instanceof Secretaria){
			Secretaria.getSalario();
		}

	}






}

