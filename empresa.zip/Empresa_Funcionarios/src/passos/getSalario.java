package passos;

public interface getSalario {
	
    	public double getSalario();	
	}


