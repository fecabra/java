package passos;

public class Secretaria extends Empresa implements getSalario{
	
     private double previdencia;
     
     public Secretaria(int ID, String nome, double salario){
           super(ID, nome, salario );
     }
     
     @Override
     public double getSalario() {
           return(salario*(1-previdencia));
           }
     
     public void setPrevidencia(double previdencia ){
           this.previdencia=0.05;
     }    
};
