package passos;

public class Gerente extends Empresa implements getSalario{
	
     private double adicional;
     private double previdencia;
     
     public Gerente(int ID, String nome, double salario){
           super(ID, nome, salario);
     }
     

	 @Override
     public double getSalario() {
           return(salario*((1- previdencia)+ adicional));
           }
     
     public void alteraAdicional(double novo_percentual){
           this.adicional = adicional*(1+novo_percentual);
           }
     
     
     public void getAdicional( double previdencia,double adicional){
           this.previdencia=0.07;
           this.adicional = adicional;
     }
}